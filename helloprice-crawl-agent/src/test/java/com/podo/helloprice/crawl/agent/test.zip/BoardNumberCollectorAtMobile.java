package com.podo.helloprice.crawl.agent.test;

import org.junit.jupiter.api.Test;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;


class BoardNumberCollectorAtMobile {

    private static final String FILE = "c://dev/hello.txt";
    private static final String NEXT_PAGE_SELECTOR = "#container > section.left_content.result > article:nth-child(3) > div.bottom_paging_box > a.search_next";
    private static final String START_BOARD_LIST = "https://gall.dcinside.com/board/lists/?id=etc_program&page=1&search_pos=-3358550&s_type=search_name&s_keyword=%EB%8F%90%EC%84%9D";
    private static final String BOARD_URL_SELECTOR = "body > div > div > div > section:nth-child(4) > ul > li > div > a.lt";
    private static final String PAGE_BUTTON_SELECTOR = "#pagination_div > span > a";
    private Set<String> boardListUrls = new LinkedHashSet<>();
    private Set<String> borderUrls = new HashSet<>();

    @Test
    void test()  {

        final ChromeDriver chromeDriver = ChromeDriverUtil.get();

        ChromeDriverUtil.movePage(chromeDriver, START_BOARD_LIST);

        collectBoardList(chromeDriver, 100);

        for (String url : boardListUrls) {
            System.out.println("게시글 번호 가져오기 : " + url);
            getBoardUrl(chromeDriver, url);
        }

        System.out.println("총게시글 수 : "  + borderUrls.size());


        File file = new File(FILE);

        try {
            FileWriter fw = new FileWriter(file);
            final List<String> collect = new ArrayList<>(borderUrls).stream()
                    .sorted()
                    .collect(Collectors.toList())
                    .stream()
                    .sorted(Comparator.reverseOrder())
                    .collect(Collectors.toList());

            for (String s : collect) {
                fw.write(s  + "\n");
            }
            fw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void collectBoardList(ChromeDriver chromeDriver, int maxBoardList) {
        final List<String> pageUrls = movePageAndGetNum(chromeDriver, PAGE_BUTTON_SELECTOR);

        this.boardListUrls.addAll(pageUrls);

        if (boardListUrls.size() > maxBoardList) {
            return;
        }

        //NEXT
        try {
            final WebElement element = ElementUtil.getElement(chromeDriver, NEXT_PAGE_SELECTOR);
            if (Objects.nonNull(element)) {
                element.click();
                collectBoardList(chromeDriver, maxBoardList);
            }
        }catch (Exception e){
            System.out.println(chromeDriver.getCurrentUrl());
            e.printStackTrace();
        }
    }

    private List<String> movePageAndGetNum(ChromeDriver chromeDriver, String pageButtonSelector) {
        final List<String> strings = new ArrayList<>();
        final List<WebElement> elements = ElementUtil.getElements(chromeDriver, pageButtonSelector);

        for (WebElement element : elements) {
            final String src = element.getAttribute("href");
            strings.add(src);
        }

        return strings;
    }

    private void getBoardUrl(ChromeDriver chromeDriver, String url) {
        ChromeDriverUtil.movePage(chromeDriver, url);
        final List<WebElement> elements = ElementUtil.getElements(chromeDriver, BOARD_URL_SELECTOR);
        for (WebElement element : elements) {
            borderUrls.add(element.getText());
        }
    }




}
